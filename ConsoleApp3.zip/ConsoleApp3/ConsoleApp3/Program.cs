﻿using System.Net.WebSockets;
using System.Text;
using System.Text.Json;

namespace ConsoleApp3
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            // 실제 JWT 토큰으로 교체하세요.
            string jwtToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyUGlkIjoiMSIsInVzZXJJZCI6Ik1hc3RlciIsIlJvbGUiOiJNYXN0ZXIiLCJleHAiOjE3NDYxNjM1NDYsImlzcyI6Imh0dHBzOi8vZXhhbXBsZS5jb20vIiwiYXVkIjoiaHR0cHM6Ly9leGFtcGxlLmNvbS8ifQ.bpHryjKSJViDu6GkW-9YKP3aUKjWkxOyElv6neOZEYI\r\n";

            // WebSocket 서버의 URI (예: 로컬 테스트 시)
            var serverUri = new Uri("wss://localhost:7266/ws");

            using (ClientWebSocket client = new ClientWebSocket())
            {
                // JWT 토큰을 Authorization 헤더에 추가하여 인증 정보를 전달합니다.
                client.Options.SetRequestHeader("Authorization", "Bearer " + jwtToken);


                try
                {
                    Console.WriteLine("Connecting to server...");
                    await client.ConnectAsync(serverUri, CancellationToken.None);
                    Console.WriteLine("Connected!");

                    // 그룹에 자동으로 가입 (join 명령 전송)
                    
                    var joinMessageObject = new
                    {
                        command = "join",
                        group = "group1",
                        message = "123123"
                    };
                    string joinJson = JsonSerializer.Serialize(joinMessageObject);
                    byte[] joinBytes = Encoding.UTF8.GetBytes(joinJson);
                    await client.SendAsync(new ArraySegment<byte>(joinBytes),
                                           WebSocketMessageType.Text,
                                           true,
                                           CancellationToken.None);
                    
                    // 수신 및 전송 작업을 동시에 실행
                    var receivingTask = ReceiveMessagesAsync(client);
                    var sendingTask = SendMessagesAsync(client);

                    await Task.WhenAll(receivingTask, sendingTask);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }
        // 서버로부터 메시지를 수신하는 Task
        private static async Task ReceiveMessagesAsync(ClientWebSocket client)
        {
            var buffer = new byte[1024 * 4];

            while (client.State == WebSocketState.Open)
            {
                var result = await client.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                if (result.MessageType == WebSocketMessageType.Text)
                {
                    string message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    Console.WriteLine("Received: " + message);
                }
                else if (result.MessageType == WebSocketMessageType.Close)
                {
                    Console.WriteLine("Server closed connection");
                    await client.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", CancellationToken.None);
                }
            }
        }

        // 서버로 메시지를 전송하는 Task
        private static async Task SendMessagesAsync(ClientWebSocket client)
        {


            while (client.State == WebSocketState.Open)
            {
                // 콘솔에서 입력받은 메시지를 가져옵니다.
                string input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    continue;
                }

                // JSON 형식의 명령 메시지 생성
                var messageObject = new
                {
                    command = "send",
                    group = "group1",  // 필요한 그룹명으로 변경 가능
                    message = input
                };

                // JSON 문자열로 직렬화
                string jsonMessage = JsonSerializer.Serialize(messageObject);
                byte[] bytes = Encoding.UTF8.GetBytes(jsonMessage);

                await client.SendAsync(
                    new ArraySegment<byte>(bytes),
                    WebSocketMessageType.Text,
                    true,
                    CancellationToken.None);
            }
        }
    }
}
